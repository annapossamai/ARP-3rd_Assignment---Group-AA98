# Run the master process
./bin/master 
